const crypto=require('crypto');
const RU=process.env.KV_REST_API_URL||process.env.UPSTASH_REDIS_REST_URL;
const RT=process.env.KV_REST_API_TOKEN||process.env.UPSTASH_REDIS_REST_TOKEN;
const BOT=process.env.BOT_TOKEN, ADMIN=String(process.env.ADMIN_ID||'');
const NFTS={pepe:2500,plane:4500,bear:100}, RATE=500, MIN_PAYOUT=150, MAX_NFT=3, REF_TAPS=10;
const CRYSTAL_COST=249;
const GIFTS={a6813:{n:'Кристалл',v:6813,w:.5},a5617:{n:'Часы',v:5617,w:.8},a3699:{n:'Шлем',v:3699,w:1.5},a2578:{n:'Шапка',v:2578,w:2.5},a2477:{n:'Брелок',v:2477,w:2.7},a1595:{n:'Мегафон',v:1595,w:4},a1533:{n:'Слон',v:1533,w:4.2},a1241:{n:'Шкатулка',v:1241,w:6},a1049:{n:'Цилиндр',v:1049,w:8},a890:{n:'Ангел-кролик',v:890,w:10},a665:{n:'Жезл',v:665,w:14},a545:{n:'Сундук',v:545,w:20},a438:{n:'Леденец',v:438,w:25.8}};
function rollCrystal(){
  const c=crypto;
  if(c.randomInt(0,100)<5){let x=c.randomInt(0,10000)/100;for(const k in GIFTS){x-=GIFTS[k].w;if(x<0)return k;}return 'a438';}
  return c.randomInt(0,100)<74?'c25':'c50';
}
const ownRc=l=>5+2.5*(l||0);
async function db(...c){
  const x=await fetch(RU,{method:'POST',headers:{Authorization:'Bearer '+RT},body:JSON.stringify(c)});
  const j=await x.json(); if(j.error)throw new Error(j.error); return j.result;
}
function auth(init){
  if(!init)return null;
  const p=new URLSearchParams(init), h=p.get('hash'); p.delete('hash');
  const s=[...p.entries()].map(([k,v])=>k+'='+v).sort().join('\n');
  const key=crypto.createHmac('sha256','WebAppData').update(BOT).digest();
  if(!h||crypto.createHmac('sha256',key).update(s).digest('hex')!==h)return null;
  if(Date.now()/1000-Number(p.get('auth_date'))>259200)return null;
  try{return JSON.parse(p.get('user'))}catch(e){return null}
}
async function getU(id){const v=await db('GET','u:'+id);return v?JSON.parse(v):null}
const putU=u=>db('SET','u:'+u.id,JSON.stringify(u));
const newUser=t=>({id:t.id,name:'',username:'',premium:false,rc:0,stars:0,taps:0,earned:0,nfts:[],auto:false,ownLvl:0,refBy:null,refs:[],paid:{},refEarned:0,banned:false,lt:0,created:Date.now()});
const me=u=>({rc:u.rc,stars:u.stars,taps:u.taps,earned:u.earned,nfts:u.nfts,auto:u.auto,ownLvl:u.ownLvl,refEarned:u.refEarned,inv:u.inv||[]});
async function tg(method,body){
  const r=await fetch(`https://api.telegram.org/bot${BOT}/${method}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  return r.json();
}
const kb=id=>({inline_keyboard:[[{text:'✅ Одобрить',callback_data:'w:a:'+id}],[{text:'🔄 На доработку',callback_data:'w:d:'+id},{text:'❌ Отклонить',callback_data:'w:r:'+id}],[{text:'🚫 Забанить',callback_data:'w:b:'+id}]]});
module.exports={CRYSTAL_COST,GIFTS,rollCrystal,db,auth,getU,putU,newUser,me,tg,kb,ADMIN,NFTS,RATE,MIN_PAYOUT,MAX_NFT,REF_TAPS,ownRc};
