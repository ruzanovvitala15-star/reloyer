const L=require('./_lib'), {db,tg}=L;
const say=(t,extra)=>tg('sendMessage',Object.assign({chat_id:L.ADMIN,text:t},extra||{}));
const ST={pending:'⏳ ожидает',paid:'✅ одобрена',rejected:'❌ отклонена',revise:'🔄 на доработку'};

async function resolve(id,act,note){
  const raw=await db('GET','w:'+id); if(!raw)return 'Заявка не найдена';
  const w=JSON.parse(raw); if(w.status!=='pending')return 'Уже обработана: '+ST[w.status];
  const u=await L.getU(w.uid), nft=w.type==='nft', what=nft?'«'+w.gift+'»':w.stars+' ⭐';
  const back=()=>{if(!u)return;if(nft){u.inv=u.inv||[];u.inv.push(w.item);}else u.stars+=w.stars;};
  const ret=nft?'Подарок возвращён в инвентарь.':'Stars возвращены на баланс.';
  if(act==='a'){w.status='paid';if(!nft)await db('INCRBY','stat:paid',w.stars);}
  else if(act==='r'){w.status='rejected';back();}
  else if(act==='d'){w.status='revise';w.note=note||'';back();}
  else if(act==='b'){w.status='rejected';if(u)u.banned=true;}
  await db('SET','w:'+id,JSON.stringify(w));await db('SREM','wpend',String(id));
  if(u)await L.putU(u);
  if(u&&act!=='b'){
    const m={a:`✅ Вывод ${what} одобрен!`,r:`❌ Вывод ${what} отклонён. ${ret}`,d:`🔄 Вывод ${what} отправлен на доработку.\nПричина: ${note}\n${ret} Отправь заявку заново.`}[act];
    await tg('sendMessage',{chat_id:u.id,text:m});
  }
  return 'Заявка #W'+id+' → '+ST[w.status]+(act==='b'?' + бан':'');
}
const card=u=>`👤 ${u.name} (ID ${u.id})${u.premium?' ⭐Premium':''}\nRC: ${Math.floor(u.rc)} · Stars: ${u.stars}\nТапов: ${u.taps} · Заработано: ${Math.floor(u.earned)}\nNFT: ${u.nfts.join(', ')||'—'} · Авто: ${u.auto?'да':'нет'} · Ур.своего: ${u.ownLvl}\nИнвентарь: ${(u.inv||[]).length} · Рефералов: ${u.refs.length} (по реф.: ${Math.floor(u.refEarned)} RC)\nПриглашён: ${u.refBy||'—'}\nСтатус: ${u.banned?'🚫 БАН':'активен'}`;
const ukb=u=>({inline_keyboard:[[u.banned?{text:'♻️ Разбанить',callback_data:'u:ub:'+u.id}:{text:'🚫 Забанить',callback_data:'u:b:'+u.id}]]});
async function find(a){
  if(!a)return null; a=a.replace('@','').toLowerCase();
  const id=/^\d+$/.test(a)?a:await db('GET','un:'+a); return id?L.getU(id):null;
}
async function cmd(text){
  const [c,a,b]=text.split(/\s+/), now=Date.now();
  if(c==='/stats'){
    const [users,d1,h1,nw,pend,taps,paid]=await Promise.all([db('SCARD','users'),db('ZCOUNT','act',now-864e5,'+inf'),db('ZCOUNT','act',now-36e5,'+inf'),db('ZCOUNT','join',now-864e5,'+inf'),db('SMEMBERS','wpend'),db('GET','stat:taps'),db('GET','stat:paid')]);
    let ps=0;if(pend.length)(await db('MGET',...pend.map(i=>'w:'+i))).forEach(x=>{const w=JSON.parse(x);if(w.type!=='nft')ps+=w.stars;});
    return say(`📊 Статистика\nИгроков: ${users}\nНовых за 24ч: ${nw}\nАктивных за 24ч: ${d1} · за час: ${h1}\nВсего тапов: ${taps||0}\nЗаявок в ожидании: ${pend.length} (${ps} ⭐)\nВыплачено: ${paid||0} ⭐`);
  }
  if(c==='/user'){const u=await find(a);return u?say(card(u),{reply_markup:ukb(u)}):say('Не найден. /user ID или @username');}
  if(c==='/ban'||c==='/unban'){const u=await find(a);if(!u)return say('Не найден');u.banned=c==='/ban';await L.putU(u);return say(u.name+(u.banned?' забанен':' разбанен'));}
  if(c==='/give'){
    const [,,,n]=text.split(/\s+/), u=await find(a), amt=Math.floor(Number(n));
    if(!u||!b)return say('Использование:\n/give ID pepe|plane|bear|auto\n/give ID rc 5000\n/give ID stars 50\n/give ID a6813 (приз Crystal в инвентарь)');
    let what;
    if(b==='auto'){u.auto=true;what='автокликер';}
    else if(L.NFTS[b]){if(u.nfts.length>=L.MAX_NFT)return say('У игрока уже 3 NFT');if(!u.nfts.includes(b))u.nfts.push(b);what=b;}
    else if(b==='rc'||b==='stars'){if(!(amt>0))return say('Укажи число: /give ID '+b+' 100');u[b]+=amt;what=amt+(b==='rc'?' RC':' ⭐');}
    else if(L.GIFTS[b]){u.inv=u.inv||[];u.inv.push({id:require('crypto').randomBytes(5).toString('hex'),k:b,ts:now});what='«'+L.GIFTS[b].n+'» (в инвентарь)';}
    else return say('Не знаю такой предмет: '+b);
    await L.putU(u);await tg('sendMessage',{chat_id:u.id,text:'🎁 Тебе выдано: '+what});return say('Выдано '+what+' → '+u.name);
  }
  if(c==='/top'){
    const z=await db('ZREVRANGE','top',0,9,'WITHSCORES');let t='🏆 Топ по RC\n';
    for(let i=0;i<z.length;i+=2){const u=await L.getU(z[i]);t+=`${i/2+1}. ${u?u.name:z[i]} — ${Math.floor(z[i+1])}\n`;}
    return say(t);
  }
  if(c==='/pending'){
    const ids=await db('SMEMBERS','wpend');if(!ids.length)return say('Заявок нет');
    for(const i of ids){const w=JSON.parse(await db('GET','w:'+i));await say(`💸 #W${w.id} · ${w.name} (ID ${w.uid}) · ${w.type==='nft'?w.gift:w.stars+' ⭐'}`,{reply_markup:L.kb(w.id)});}
    return;
  }
  return say('/stats /top /pending\n/user ID|@name\n/ban ID · /unban ID\n/give ID pepe|plane|bear|auto|rc N|stars N|a6813');
}
module.exports=async(req,res)=>{
  try{
    if(process.env.WEBHOOK_SECRET&&req.headers['x-telegram-bot-api-secret-token']!==process.env.WEBHOOK_SECRET)return res.status(403).end();
    const up=typeof req.body==='string'?JSON.parse(req.body):req.body, m=up.message, cb=up.callback_query;
    if(m&&m.text){
      if(/^\/start/.test(m.text))await tg('sendMessage',{chat_id:m.chat.id,text:'Добро пожаловать в RELIC! Жми кнопку и начинай 👇',reply_markup:{inline_keyboard:[[{text:'🎮 Играть',web_app:{url:process.env.APP_URL}}]]}});
      else if(String(m.from.id)===L.ADMIN){
        const rt=m.reply_to_message&&m.reply_to_message.text&&m.reply_to_message.text.match(/#W(\d+)/);
        if(rt&&!m.text.startsWith('/'))await say(await resolve(rt[1],'d',m.text));
        else await cmd(m.text);
      }
    }
    if(cb&&String(cb.from.id)===L.ADMIN){
      const [k,act,id]=cb.data.split(':');
      await tg('answerCallbackQuery',{callback_query_id:cb.id});
      if(k==='w'){
        if(act==='d')await say(`Напиши причину доработки ответом на это сообщение (#W${id})`,{reply_markup:{force_reply:true}});
        else{const r=await resolve(id,act);
          await tg('editMessageText',{chat_id:cb.message.chat.id,message_id:cb.message.message_id,text:cb.message.text+'\n\n→ '+r});}
      }else if(k==='u'){
        const u=await L.getU(id);if(u){u.banned=act==='b';await L.putU(u);
          await tg('editMessageText',{chat_id:cb.message.chat.id,message_id:cb.message.message_id,text:card(u),reply_markup:ukb(u)});}
      }
    }
  }catch(e){console.error(e);}
  res.status(200).end();
};
