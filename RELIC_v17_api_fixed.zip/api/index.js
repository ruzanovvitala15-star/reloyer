const L=require('./_lib');
module.exports=async(req,res)=>{
  try{
    const b=typeof req.body==='string'?JSON.parse(req.body||'{}'):(req.body||{});
    const tu=L.auth(b.initData);
    if(!tu)return res.status(401).json({error:'auth'});
    const route=req.query.p, now=Date.now();
    let u=await L.getU(tu.id), isNew=false;
    if(!u){isNew=true;u=L.newUser(tu);await L.db('SADD','users',String(u.id));await L.db('ZADD','join',now,String(u.id));}
    u.name=tu.username?'@'+tu.username:[tu.first_name,tu.last_name].filter(Boolean).join(' ')||'Игрок';
    u.username=tu.username||''; u.premium=!!tu.is_premium;
    if(u.banned)return res.status(403).json({banned:true});
    if(u.username)await L.db('SET','un:'+u.username.toLowerCase(),String(u.id));
    await L.db('ZADD','act',now,String(u.id));
    const out={ok:true}; const fail=e=>{out.ok=false;out.error=e};

    if(route==='join'&&(isNew||(!u.refBy&&u.taps===0))){
      const ref=String(b.ref||'');
      if(/^\d+$/.test(ref)&&ref!==String(u.id)){
        const r=await L.getU(ref);
        if(r&&String(r.refBy)!==String(u.id)){u.refBy=ref;if(!r.refs.includes(String(u.id))){r.refs.push(String(u.id));await L.putU(r);}}
      }
    }
    else if(route==='tap'){
      const dt=Math.min((now-(u.lt||now-5000))/1000,60), cap=Math.floor(dt*30)+30;
      const n=Math.max(0,Math.min(parseInt(b.n)||0,cap));
      const per=(b.active&&L.NFTS[b.active]&&u.nfts.includes(b.active))?L.NFTS[b.active]:L.ownRc(u.ownLvl);
      u.rc+=n*per;u.earned+=n*per;u.taps+=n;u.lt=now;
      if(n){await L.db('INCRBY','stat:taps',n);await L.db('ZADD','top',u.earned,String(u.id));}
    }
    else if(route==='upgrade'){
      const cost=Math.round((L.ownRc(u.ownLvl)+2.5)*40);
      if(u.rc<cost)fail('Не хватает RC');else{u.rc-=cost;u.ownLvl++;}
    }
    else if(route==='exchange'){
      const n=Math.floor(b.stars), max=Math.floor(u.rc/L.RATE);
      if(!(n>=1)||n>max)fail('Недостаточно RC');else{u.rc-=n*L.RATE;u.stars+=n;}
    }
    else if(route==='payout'){
      const n=Math.floor(b.stars);
      if(!(n>=L.MIN_PAYOUT))fail('Минимум '+L.MIN_PAYOUT+' ⭐');
      else if(n>u.stars)fail('Недостаточно Stars');
      else{
        const id=await L.db('INCR','wid');
        const w={id,uid:u.id,name:u.name,stars:n,status:'pending',note:'',ts:now};
        u.stars-=n;
        await L.db('SET','w:'+id,JSON.stringify(w));await L.db('LPUSH','uw:'+u.id,String(id));await L.db('SADD','wpend',String(id));
        await L.tg('sendMessage',{chat_id:L.ADMIN,reply_markup:L.kb(id),
          text:`💸 Заявка #W${id}\nИгрок: ${u.name} (ID ${u.id})${u.premium?' ⭐Premium':''}\nСумма: ${n} ⭐\nВсего тапов: ${u.taps}\nЗаработано RC: ${Math.floor(u.earned)}\nРефералов: ${u.refs.length}\nNFT: ${u.nfts.join(', ')||'—'}`});
      }
    }
    else if(route==='case'){
      if(b.id==='crystal'){
        if(u.stars<L.CRYSTAL_COST)fail('stars');
        else{
          u.stars-=L.CRYSTAL_COST;
          const pz=L.rollCrystal();out.prize=pz;
          if(pz[0]==='a'){
            u.inv=u.inv||[];u.inv.push({id:require('crypto').randomBytes(5).toString('hex'),k:pz,ts:now});
            await L.tg('sendMessage',{chat_id:L.ADMIN,text:`💎 Crystal: ${u.name} (ID ${u.id}) выиграл NFT «${L.GIFTS[pz].n}» (${L.GIFTS[pz].v} ⭐)`});
          }else u.stars+=Number(pz.slice(1));
        }
      }
      else if((u.caseAt||0)+864e5>now)fail('wait');
      else{
        // Free case is available to every authenticated user; channel subscription is not required.
        const r=require('crypto').randomInt(1,101);
        const prize=r<=1?'s100':r<=6?'s50':r<=21?'r5000':r<=50?'r2500':'r500';
        if(prize[0]==='s')u.stars+=Number(prize.slice(1));else u.rc+=Number(prize.slice(1));
        u.caseAt=now;out.prize=prize;
        if(prize[0]==='s')await L.tg('sendMessage',{chat_id:L.ADMIN,text:`🎁 Кейс: ${u.name} (ID ${u.id}) выиграл ${prize.slice(1)} ⭐`});
      }
    }
    else if(route==='giftout'){
      u.inv=u.inv||[];const i=u.inv.findIndex(x=>x.id===b.gid);
      if(i<0)fail('Подарок не найден');
      else{
        const it=u.inv.splice(i,1)[0],g=L.GIFTS[it.k],id=await L.db('INCR','wid');
        const w={id,uid:u.id,name:u.name,type:'nft',item:it,gift:g.n,stars:g.v,status:'pending',note:'',ts:now};
        await L.db('SET','w:'+id,JSON.stringify(w));await L.db('LPUSH','uw:'+u.id,String(id));await L.db('SADD','wpend',String(id));
        await L.tg('sendMessage',{chat_id:L.ADMIN,reply_markup:L.kb(id),text:`🎁 Заявка #W${id} на вывод NFT\nИгрок: ${u.name} (ID ${u.id})\nПодарок: ${g.n} (${g.v} ⭐)`});
      }
    }
    else if(route==='payouts'){
      const ids=await L.db('LRANGE','uw:'+u.id,0,9);
      const v=ids.length?await L.db('MGET',...ids.map(i=>'w:'+i)):[];
      out.payouts=v.filter(Boolean).map(x=>{const w=JSON.parse(x);return{id:w.id,stars:w.stars,status:w.status,note:w.note,gift:w.gift||''}});
    }
    else if(route==='refs'){
      let gained=0;const list=[];
      for(const id of u.refs){
        const r=await L.getU(id); if(!r)continue;
        list.push({id:String(r.id),name:r.name,taps:r.taps,premium:r.premium});
        if(r.taps>=L.REF_TAPS&&!u.paid[id]){u.paid[id]=1;const v=r.premium?15000:5000;u.rc+=v;u.earned+=v;u.refEarned+=v;gained+=v;}
      }
      out.refs=list;out.gained=gained;
    }
    await L.putU(u);
    out.me=L.me(u);out.caseLeft=Math.max(0,(u.caseAt||0)+864e5-now);
    res.status(200).json(out);
  }catch(e){console.error(e);res.status(500).json({error:'server'});}
};
