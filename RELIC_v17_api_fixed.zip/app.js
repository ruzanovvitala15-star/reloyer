const NFTS={
  pepe:{name:'Plush Pepe',rc:2500,stars:800,cls:'pepe-art'},
  plane:{name:'Telegram',rc:4500,stars:999,cls:'plane-art'},
  bear:{name:'Teddy',rc:100,stars:25,cls:'bear-art'}
};
const MIN_PAYOUT=150, RATE=500, MAX_NFT=3, SELLER='https://t.me/RelicReleyer', KEY='relic_state_v1';
const LEVELS=[[0,'Новичок'],[50000,'Искатель'],[250000,'Охотник'],[1000000,'Хранитель'],[5000000,'Мастер'],[25000000,'Легенда']];
const tg=window.Telegram&&Telegram.WebApp; if(tg){tg.ready();tg.expand();}
const BOT_USERNAME='RCRelic_bot'; // <- username твоего бота (без @)
const API_URL='/api';                       // <- адрес бэкенда (пусто = локальный режим)
const REF_TAPS=10, REF_REWARD=5000, REF_REWARD_PREMIUM=15000;
const U=(tg&&tg.initDataUnsafe&&tg.initDataUnsafe.user)||null;
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function ownName(){return U?(U.username?'@'+U.username:[U.first_name,U.last_name].filter(Boolean).join(' ')||'Игрок'):'Игрок RELIC';}
function ownAvatar(){
  if(U&&U.photo_url)return U.photo_url;
  const n=esc((ownName().replace('@','')[0]||'R').toUpperCase());
  return 'data:image/svg+xml;utf8,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#6df3ff"/><stop offset="1" stop-color="#1d8fff"/></linearGradient></defs><rect width="100" height="100" fill="url(#g)"/><text x="50" y="68" font-size="54" font-weight="800" text-anchor="middle" fill="#fff" font-family="Arial,sans-serif">'+n+'</text></svg>');
}
const pic=id=>id==='own'?`<img class="avatar-nft" src="${esc(ownAvatar())}" alt="" draggable="false">`:`<img src="/${id}.png" alt="" draggable="false" onerror="this.onerror=null;this.src='/${id}.svg'">`;
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const fmt=n=>Math.floor(n).toLocaleString('ru-RU');
const fmtR=n=>Number.isInteger(n)?fmt(n):n.toLocaleString('ru-RU',{maximumFractionDigits:1});
const def=()=>({rc:0,stars:0,taps:0,earned:0,nfts:[],active:null,auto:false,payouts:[],ownLvl:0,refs:[],paidRefs:{},refEarned:0,referredBy:null,joined:false});
let S=(()=>{try{return Object.assign(def(),JSON.parse(localStorage.getItem(KEY)))}catch(e){return def()}})();
const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){}};
// личный NFT: аватар игрока, 5 RC за тап, +2.5 за уровень
const ownRc=()=>5+2.5*(S.ownLvl||0);
NFTS.own={get name(){return ownName()},get rc(){return ownRc()},cls:'own-art'};
function upInfo(){const next=ownRc()+2.5;return {next,cost:Math.round(next*40)};}
const bind=(sel,html)=>$$(sel).forEach(e=>e.innerHTML=html);
const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;

/* ---------- навигация ---------- */
function go(id){
  $$('.screen').forEach(s=>s.classList.toggle('active',s.id===id));
  $$('.nav-btn').forEach(b=>b.classList.toggle('active',b.dataset.screen===id));
  scrollTo({top:0});
}
$$('.nav-btn').forEach(b=>b.onclick=()=>go(b.dataset.screen));
document.addEventListener('click',e=>{
  const g=e.target.closest('[data-goto]'); if(g) go(g.dataset.goto);
  const m=e.target.closest('[data-modal]'); if(m){ $('#'+m.dataset.modal).hidden=false; if(m.dataset.modal==='exchange-modal')exUpd(); if(m.dataset.modal==='payout-modal')poUpd(); }
  const c=e.target.closest('[data-close]'); if(c) $('#'+c.dataset.close).hidden=true;
  const t=e.target.closest('[data-tab]'); if(t){
    $$('[data-tab]').forEach(x=>x.classList.toggle('active',x===t));
    $$('.tab-panel').forEach(p=>p.classList.toggle('active',p.id===t.dataset.tab));
  }
  const up=e.target.closest('[data-upgrade]'); if(up){flush().then(()=>api('/upgrade',{})).then(d=>toast(!d?'Ошибка сети — попробуй ещё раз':d.ok?'Прокачано · +'+fmtR(ownRc())+' RC за тап':'Не хватает '+fmt(upInfo().cost-S.rc)+' RC'));}
  if(e.target.closest('[data-copy-ref]')){try{navigator.clipboard.writeText(refLink());}catch(err){} toast('Ссылка скопирована');}
  if(e.target.closest('[data-share-ref]')){const su='https://t.me/share/url?url='+encodeURIComponent(refLink())+'&text='+encodeURIComponent('Залетай в RELIC — тапай и получай RC!'); if(tg&&tg.openTelegramLink)tg.openTelegramLink(su); else window.open(su,'_blank');}
  const sl=e.target.closest('[data-pick]'); if(sl){S.active=sl.dataset.pick;save();render();toast('Активный NFT: '+NFTS[S.active].name);}
  const buy=e.target.closest('a.shop-buy');
  if(buy){ if(buy.classList.contains('disabled')){e.preventDefault();return;}
    if(tg&&tg.openTelegramLink){e.preventDefault();tg.openTelegramLink(SELLER);} }
});
$$('.modal-backdrop').forEach(m=>m.addEventListener('click',e=>{if(e.target===m)m.hidden=true}));

/* ---------- уровень ---------- */
function level(){let i=0;LEVELS.forEach((l,k)=>{if(S.earned>=l[0])i=k});
  const cur=LEVELS[i][0],next=LEVELS[i+1];
  return {n:i+1,name:LEVELS[i][1],pct:next?Math.min(100,(S.earned-cur)/(next[0]-cur)*100):100,max:!next};}

/* ---------- отрисовка ---------- */
function toast(t){const el=$('#toast');el.textContent=t;el.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(()=>el.classList.remove('show'),2200);}
function renderStats(){
  const L=level(),a=S.active&&NFTS[S.active];
  const upx=upInfo(); $$('[data-upgrade]').forEach(b=>b.disabled=S.rc<upx.cost);
  bind('.balance-value',fmt(S.rc)+' <small>RC</small>');
  bind('.tap-count',fmt(S.taps)+' <small>тапов</small>');
  bind('.tap-footer b',a?'+'+fmtR(a.rc)+' RC':'— RC');
  bind('.stats-row .stat:nth-child(1) b',fmt(S.earned)+' <small>RC</small>');
  bind('.stats-row .stat:nth-child(2) b',S.nfts.length);
  bind('.level-name span','УРОВЕНЬ '+L.n); bind('.level-name b',L.name);
  bind('.level-next',L.max?'MAX':L.n+1); $('.progress span').style.width=L.pct+'%';
  $('#p-rc').textContent=fmt(S.rc)+' RC'; $('#p-stars').textContent=fmt(S.stars)+' ⭐';
  $('#p-level').textContent='Уровень '+L.n+' · '+L.name; $('#p-taps').textContent=fmt(S.taps);
  $('#tg-lvl').textContent=L.n;
  $$('#exchange-modal .wallet-balance:nth-child(1) b').forEach(e=>e.innerHTML=fmt(S.rc)+' <small>RC</small>');
  if(typeof exUpd==='function'&&exIn){exUpd();poUpd();}
  $$('.wallet-balance.stars b').forEach(e=>e.innerHTML=fmt(S.stars)+' <small>⭐</small>');
}
function render(){
  settleRefs();
  if(S.active!=='own'&&!S.nfts.includes(S.active)) S.active=null;
  if(!S.active) S.active='own';
  const a=S.active&&NFTS[S.active], full=S.nfts.length>=MAX_NFT;
  renderStats();
  // сцена
  $('#nft').hidden=$('#nft-shadow').hidden=!a; $('#empty-item').hidden=!!a;
  if(a){$('#nft').className='nft '+a.cls;$('#nft-emoji').innerHTML=pic(S.active);}
  $('#auto-badge').hidden=!S.auto;
  // выбор NFT на главной
  $('#picker').innerHTML=S.nfts.length>=1?['own',...S.nfts].map(id=>`<button type="button" data-pick="${id}" class="chip ${id===S.active?'on':''}">${pic(id)}<b>+${fmtR(NFTS[id].rc)}</b></button>`).join(''):'';
  // слоты профиля
  let slots='';
  for(let i=0;i<MAX_NFT;i++){const id=S.nfts[i];
    slots+=id?`<button type="button" class="slot filled" data-pick="${id}"><div class="slot-art ${NFTS[id].cls}">${pic(id)}${id===S.active?'<em>АКТИВЕН</em>':''}</div><b>${NFTS[id].name}</b><small>+${fmtR(NFTS[id].rc)} RC / тап</small></button>`
      :`<button type="button" class="slot empty" data-goto="shop-screen"><div class="slot-plus">+</div><b>Пусто</b><small>В магазин</small></button>`;}
  $('#slots').innerHTML=slots;
  renderOwn(); renderRefs();
  $('#tab-count').textContent=S.nfts.length+'/'+MAX_NFT;
  $('#auto-status').innerHTML=S.auto?'<b>⚡ Автокликер активен</b><span>60 кликов в час — сам тапает по активному NFT</span>':'<b>Автокликер не куплен</b><span>60 кликов в час · 100 ⭐ в магазине</span>';
  $('#auto-status').classList.toggle('on',S.auto);
  // магазин
  $('#shop-slots').textContent=S.nfts.length+' / '+MAX_NFT+' NFT';
  $$('.shop-card[data-nft] .shop-buy').forEach(b=>{b.classList.toggle('disabled',full);b.textContent=full?'Нет мест':'Купить';});
  const ab=$('#auto-card .shop-buy'); ab.classList.toggle('disabled',S.auto); ab.textContent=S.auto?'Куплено ✓':'Купить';
  save();
}

/* ---------- тап + анимация проседания ---------- */
const stage=$('#stage'); let anim=null,shadowAnim=null;
function squish(){
  const el=$('#nft'),sh=$('#nft-shadow');
  if(anim)anim.cancel(); if(shadowAnim)shadowAnim.cancel();
  const d=reduce?1:430;
  anim=el.animate([
    {transform:'scale(1,1)'},
    {transform:'scale(1.2,.68) translateY(6px)',offset:.28},
    {transform:'scale(.92,1.14)',offset:.58},
    {transform:'scale(1.04,.96)',offset:.8},
    {transform:'scale(1,1)'}],{duration:d,easing:'cubic-bezier(.3,.7,.4,1)'});
  shadowAnim=sh.animate([{transform:'scale(1)',opacity:.35},{transform:'scale(1.25,1)',opacity:.5,offset:.28},{transform:'scale(.9)',opacity:.25,offset:.58},{transform:'scale(1)',opacity:.35}],{duration:d,easing:'ease-out'});
}
function tap(x,y,auto){
  const a=S.active&&NFTS[S.active]; if(!a)return;
  S.rc+=a.rc;S.earned+=a.rc;S.taps++;
  pend++;pendRc+=a.rc;
  squish(); renderStats(); save();
  const f=document.createElement('div');f.className='float'+(auto?' auto':'');f.textContent='+'+fmtR(a.rc);
  const r=stage.getBoundingClientRect();
  f.style.left=(x==null?r.width/2:x-r.left)+'px';f.style.top=(y==null?r.height/2-20:y-r.top-20)+'px';
  stage.appendChild(f);setTimeout(()=>f.remove(),900);
  if(!auto){ if(tg&&tg.HapticFeedback)tg.HapticFeedback.impactOccurred('medium'); else if(navigator.vibrate)navigator.vibrate(12); }
}
stage.addEventListener('pointerdown',e=>{ if(e.target.closest('button'))return; e.preventDefault(); tap(e.clientX,e.clientY,false); });
setInterval(()=>{ if(S.auto&&S.active){tap(null,null,true);} },60000); // 60 кликов в час = 1 в минуту

/* ---------- профиль из Telegram ---------- */
(function(){
  const u=tg&&tg.initDataUnsafe&&tg.initDataUnsafe.user; if(!u)return;
  const name=[u.first_name,u.last_name].filter(Boolean).join(' ')||'Игрок RELIC';
  $('#tg-name').textContent=name; $('#tg-initial').textContent=name[0].toUpperCase();
  $('#tg-user').textContent=u.username?'@'+u.username:'не указано';
  const cols=[['#ff885e','#ff516a'],['#ffcd6a','#ffa85c'],['#82b1ff','#665fff'],['#a0de7e','#54cb68'],['#53edd6','#28c9b7'],['#72d5fd','#2a9ef1'],['#e0a2f3','#d669ed']];
  const c=cols[Math.abs(u.id||0)%7]; $('#tg-avatar').style.background=`linear-gradient(160deg,${c[0]},${c[1]})`; const th=$('.tg-head'); th.style.setProperty('--c1',c[0]); th.style.setProperty('--c2',c[1]);
  if(u.photo_url){const p=$('#tg-photo');p.src=u.photo_url;p.hidden=false;$('#tg-initial').hidden=true;}
})();

/* шапка: ава и ник из Telegram */
(function(){
  if(!U)return; const nm=ownName();
  $('#acc-name').textContent=nm.length>14?nm.slice(0,13)+'…':nm;
  const p=$('#acc-pic'); p.textContent=(nm.replace('@','')[0]||'R').toUpperCase();
  if(U.photo_url){const im=new Image();im.alt='';im.onload=()=>{p.textContent='';p.appendChild(im);};im.src=U.photo_url;}
})();
/* ---------- личный NFT + прокачка ---------- */
function renderOwn(){
  const x=upInfo(), act=S.active==='own';
  $('#own-card').innerHTML=`<div class="own-top"><div class="own-ava">${pic('own')}</div><div class="own-copy"><span class="eyebrow">ТВОЙ NFT</span><b>${esc(ownName())}</b><small>Ур. ${S.ownLvl||0} · +${fmtR(ownRc())} RC / тап</small></div><button type="button" class="own-pick ${act?'on':''}" data-pick="own">${act?'Активен':'Выбрать'}</button></div><button type="button" class="up-btn" data-upgrade ${S.rc<x.cost?'disabled':''}>⬆ Прокачать до +${fmtR(x.next)} RC/тап · ${fmt(x.cost)} RC</button>`;
  const bar=$('#up-bar'); bar.hidden=!act;
  if(act)bar.innerHTML=`<button type="button" data-upgrade ${S.rc<x.cost?'disabled':''}>⬆ Прокачать до +${fmtR(x.next)} RC/тап · ${fmt(x.cost)} RC</button>`;
}

/* ---------- рефералы ---------- */
const refLink=()=>`https://t.me/${BOT_USERNAME}?startapp=ref_${U?U.id:'demo'}`;
async function rawApi(path,body){
  if(!API_URL)return null;
  try{const r=await fetch(API_URL+path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(Object.assign({initData:tg&&tg.initData},body))});
    const d=await r.json();
    if(d.banned){document.body.innerHTML='<div style="padding:80px 24px;text-align:center;font:700 18px sans-serif;color:#fff">🚫 Аккаунт заблокирован</div>';return null;}
    if(d.caseLeft!==undefined)S.caseEnd=Date.now()+d.caseLeft; if(d.me&&path!=='/case')applyMe(d.me); return d;}catch(e){return null;}
}
let Q=Promise.resolve();
function api(path,body){const r=Q.then(()=>rawApi(path,body));Q=r.catch(()=>{});return r;}
function settleRefs(){}
function renderRefs(){
  const refs=S.refs||[], ok=refs.filter(r=>r.taps>=REF_TAPS).length;
  $('#ref-url').textContent=refLink().replace('https://','');
  $('#ref-all').textContent=refs.length; $('#ref-ok').textContent=ok; $('#ref-earn').textContent=fmt(S.refEarned||0)+' RC';
  const cols=['#ff885e','#ffcd6a','#82b1ff','#a0de7e','#53edd6','#72d5fd','#e0a2f3'];
  $('#ref-list').innerHTML=refs.length?refs.slice().reverse().map(r=>{
    const done=r.taps>=REF_TAPS, v=r.premium?REF_REWARD_PREMIUM:REF_REWARD, nm=String(r.name||'Игрок'), c=cols[(nm.charCodeAt(nm.length-1)||0)%7], t=Math.min(r.taps,REF_TAPS);
    return `<div class="ref-item"><div class="ref-ava" style="background:${c}">${esc(nm.replace('@','')[0]||'?').toUpperCase()}</div><div class="ref-mid"><b>${esc(nm)}${r.premium?' <i class="prem-badge">Premium</i>':''}</b>${done?'<small>Засчитан</small>':`<div class="ref-bar"><span style="width:${t*10}%"></span></div>`}</div><div class="ref-right ${done?'ok':''}">${done?'+'+fmt(v)+' RC':t+'/'+REF_TAPS}</div></div>`;
  }).join(''):'<div class="empty-state"><b>Пока никого нет</b><span>Отправь ссылку другу — он появится здесь</span></div>';
}
async function syncState(){await api('/state',{});}
async function syncRefs(){const d=await api('/refs',{}); if(d&&Array.isArray(d.refs)){S.refs=d.refs;render();if(d.gained)toast('Реферал засчитан: +'+fmt(d.gained)+' RC');}}
(function(){
  const sp=tg&&tg.initDataUnsafe&&tg.initDataUnsafe.start_param;
  if(sp&&/^ref_/.test(sp)&&!S.referredBy&&String(U&&U.id)!==sp.slice(4))S.referredBy=sp.slice(4);
  api('/join',{ref:S.referredBy}).then(()=>{syncRefs();syncPayouts();});
})();

/* ---------- синхронизация с сервером ---------- */
var pend=0,pendRc=0;
function applyMe(m){S.rc=m.rc+pendRc;S.taps=m.taps+pend;S.earned=m.earned+pendRc;S.stars=m.stars;S.nfts=m.nfts;S.auto=m.auto;S.ownLvl=m.ownLvl;S.refEarned=m.refEarned;S.inv=m.inv||[];render();renderInv();renderCase();}
function flush(){if(!pend)return Promise.resolve();const n=pend,rc=pendRc;pend=0;pendRc=0;return api('/tap',{n,active:S.active}).then(d=>{if(!d){pend+=n;pendRc+=rc;}});}
setInterval(flush,2500);
document.addEventListener('visibilitychange',()=>{if(document.hidden)flush();});

/* ---------- обмен и вывод ---------- */
var exIn=$('#ex-amount'),poIn=$('#po-amount');
const ST={pending:'⏳ На рассмотрении',paid:'✅ Одобрено',rejected:'❌ Отклонено',revise:'🔄 На доработку'};
function clampIn(el,min,max){let v=parseInt(el.value)||min;v=Math.max(min,Math.min(max>=min?max:min,v));el.value=v;return v;}
function renderPo(){$('#po-list').innerHTML=(S.payouts||[]).map(p=>`<div class="processing-note"><b>${p.gift?esc(p.gift):fmt(p.stars)+' ⭐'} · ${ST[p.status]||p.status}</b>${p.note?`<span>${esc(p.note)}</span>`:''}</div>`).join('');}
function exUpd(){const max=Math.floor(S.rc/RATE),v=clampIn(exIn,1,max);$('#ex-cost').textContent=fmt(v*RATE)+' RC';$('#ex-go').disabled=max<1;}
function poUpd(){clampIn(poIn,MIN_PAYOUT,S.stars);$('#po-go').disabled=S.stars<MIN_PAYOUT;renderPo();}
async function syncPayouts(){const d=await api('/payouts',{});if(d&&d.payouts){S.payouts=d.payouts;renderPo();}}
$('#ex-minus').onclick=()=>{exIn.value=(parseInt(exIn.value)||1)-1;exUpd();};
$('#ex-plus').onclick=()=>{exIn.value=(parseInt(exIn.value)||0)+1;exUpd();};
$('#ex-max').onclick=()=>{exIn.value=Math.floor(S.rc/RATE);exUpd();};
$('#po-minus').onclick=()=>{poIn.value=(parseInt(poIn.value)||MIN_PAYOUT)-10;poUpd();};
$('#po-plus').onclick=()=>{poIn.value=(parseInt(poIn.value)||MIN_PAYOUT)+10;poUpd();};
$('#po-max').onclick=()=>{poIn.value=S.stars;poUpd();};
exIn.oninput=exUpd; poIn.onchange=poUpd;
$('#ex-go').onclick=()=>flush().then(()=>api('/exchange',{stars:parseInt(exIn.value)||0})).then(d=>toast(d&&d.ok?'Обмен выполнен ✓':(d&&d.error)||'Ошибка сети'));
$('#po-go').onclick=()=>api('/payout',{stars:parseInt(poIn.value)||0}).then(d=>{toast(d&&d.ok?'Запрос отправлен ✓':(d&&d.error)||'Ошибка сети');if(d&&d.ok)syncPayouts();});

/* ---------- кейсы ---------- */
const GF={a6813:{n:'Кристалл',i:'💎',v:6813},a5617:{n:'Часы',i:'⌚',v:5617},a3699:{n:'Шлем',i:'🪖',v:3699},a2578:{n:'Шапка',i:'🧢',v:2578},a2477:{n:'Брелок',i:'🔮',v:2477},a1595:{n:'Мегафон',i:'📣',v:1595},a1533:{n:'Слон',i:'🐘',v:1533},a1241:{n:'Шкатулка',i:'🎁',v:1241},a1049:{n:'Цилиндр',i:'🎩',v:1049},a890:{n:'Ангел-кролик',i:'🐰',v:890},a665:{n:'Жезл',i:'🪄',v:665},a545:{n:'Сундук',i:'🧰',v:545},a438:{n:'Леденец',i:'🍬',v:438}};
const GW={a6813:.5,a5617:.8,a3699:1.5,a2578:2.5,a2477:2.7,a1595:4,a1533:4.2,a1241:6,a1049:8,a890:10,a665:14,a545:20,a438:25.8};
const FREE={s100:{t:'100 ⭐',i:'🌟',c:'#ffd24a',w:1},s50:{t:'50 ⭐',i:'⭐',c:'#ffb14a',w:5},r5000:{t:'5 000 RC',i:'💎',c:'#6df3ff',w:15},r2500:{t:'2 500 RC',i:'🪙',c:'#5ef0b4',w:29},r500:{t:'500 RC',i:'🔹',c:'#9aa8ff',w:50}};
const CRYSTAL_COST=249;
var curCase='free',csBusy=false;
function tile(k){
  const S_='<svg class="st" viewBox="0 0 24 24"><path d="M12 2.5l2.9 6.1 6.6.8-4.9 4.6 1.3 6.6L12 17.3 6.1 20.6l1.3-6.6L2.5 9.4l6.6-.8z"/></svg>';
  if(GF[k])return `<div class="rit gift"><img src="/${k}.png" alt="" draggable="false"><u>${S_}${fmt(GF[k].v)}</u></div>`;
  if(k[0]==='c'||k[0]==='s')return `<div class="rit star">${S_.replace('class="st"','class="st big"')}<b>${k.slice(1)}</b></div>`;
  return `<div class="rit rc"><span class="coin">RC</span><b>${FREE[k].t.replace(' RC','')}</b></div>`;
}
function rndPz(cid){
  if(cid==='free'){let r=Math.random()*100;for(const k in FREE){r-=FREE[k].w;if(r<=0)return k;}return 'r500';}
  if(Math.random()<.05){let r=Math.random()*100;for(const k in GW){r-=GW[k];if(r<=0)return k;}return 'a438';}
  return Math.random()<.74?'c25':'c50';
}
function buildStrip(cid,n,idx,prize){
  const a=[];for(let i=0;i<n;i++)a.push(i===idx&&prize?prize:rndPz(cid));
  $('#case-strip').innerHTML=a.map(tile).join('');
}
const tf=t=>{const f=n=>String(n).padStart(2,'0');return f(Math.floor(t/3600))+':'+f(Math.floor(t%3600/60))+':'+f(t%60);};
function renderCase(){
  $('#cs-bal').textContent=fmt(S.stars)+' ⭐';
  const left=(S.caseEnd||0)-Date.now(), t=Math.ceil(left/1000);
  $('#fc-pill').textContent=left>0?tf(t):'FREE';
  const b=$('#cs-spin');
  if(curCase==='crystal'){b.textContent='Крутить за ⭐ '+CRYSTAL_COST;b.disabled=csBusy;}
  else{b.textContent=left>0?'Следующий через '+tf(t):'Открыть бесплатно';b.disabled=csBusy||left>0;}
}
setInterval(renderCase,1000);
function showCase(cid){
  curCase=cid;csBusy=false;
  $('#cs-name').textContent=cid==='free'?'FREE24 · @RcRelicGift':'Crystal';
  $('#cs-res').innerHTML='';
  $('#cs-art').innerHTML=`<img src="/${cid==='free'?'free':'crystal'}.png" alt="">`;
  $('#cs-sub').textContent=cid==='free'?'Раз в 24 часа · доступно всем':'Stars и редкие NFT · NFT можно вывести';
  $('#case-screen').hidden=false;
  const st=$('#case-strip'),win=$('#case-win');buildStrip(cid,30,-1);
  st.style.transition='none';st.style.transform=`translateX(${-(14*142+66-win.clientWidth/2)}px)`;
  renderCase();
}
$('#fc-free').onclick=()=>showCase('free');
$('#fc-crystal').onclick=()=>showCase('crystal');
$('#cs-prizes').onclick=()=>{
  let h,note;
  if(curCase==='free'){note='Бесплатный кейс раз в 24 часа — подписка на канал не требуется.';h=Object.keys(FREE).map(tile).join('');}
  else{note='NFT попадает в инвентарь профиля, его можно вывести.';
    h=Object.keys(GF).map(tile).join('')+tile('c50')+tile('c25');}
  $('#pz-note').textContent=note;$('#pz-grid').innerHTML=h;$('#prizes-modal').hidden=false;
};
$('#cs-spin').onclick=async()=>{
  if(csBusy)return;const cid=curCase;
  if(cid==='crystal'&&S.stars<CRYSTAL_COST){toast('Нужно '+CRYSTAL_COST+' ⭐ — обменяй RC на Stars в профиле');return;}
  csBusy=true;renderCase();$('#cs-res').innerHTML='';await flush();
  const d=await api('/case',{id:cid});
  if(!d||!d.ok){
    csBusy=false;
    if(d&&d.error==='sub'){toast('Подпишись на @RcRelicGift и нажми снова');if(tg&&tg.openTelegramLink)tg.openTelegramLink('https://t.me/RcRelicGift');else window.open('https://t.me/RcRelicGift','_blank');}
    else toast(!d?'Ошибка сети: API недоступен. Проверь Deployment в Vercel':d.error==='stars'?'Не хватает Stars':d.error==='subcheck'?'Не удалось проверить подписку. Попробуй позже':'Кейс ещё не готов');
    renderCase();return;
  }
  const W=142,IDX=44,st=$('#case-strip'),win=$('#case-win');
  buildStrip(cid,56,IDX,d.prize);
  st.style.transition='none';st.style.transform='translateX(0)';st.getBoundingClientRect();
  const stop=IDX*W+66-win.clientWidth/2+(Math.random()*60-30);
  st.style.transition=reduce?'none':'transform 6.2s cubic-bezier(.1,.62,.08,1)';
  st.style.transform=`translateX(${-stop}px)`;
  setTimeout(()=>{
    st.children[IDX].classList.add('win');
    const k=d.prize;let big,sub;
    if(GF[k]){big=GF[k].n+' · ⭐ '+fmt(GF[k].v);sub='NFT добавлен в инвентарь профиля — его можно вывести.';}
    else if(k[0]==='r'){big=FREE[k].t;sub='Награда зачислена на баланс RC.';}
    else{big='⭐ +'+(FREE[k]?FREE[k].t.replace(' ⭐',''):k.slice(1));sub='Звёзды зачислены на баланс Stars и доступны только для вывода.';}
    $('#cs-res').innerHTML=`<b>${big}</b><span>${sub}</span>`;
    csBusy=false;applyMe(d.me);
    if(tg&&tg.HapticFeedback)tg.HapticFeedback.notificationOccurred('success');
  },reduce?100:6500);
};

/* ---------- инвентарь ---------- */
function renderInv(){
  const inv=S.inv||[];
  $('#inv').innerHTML=inv.length?`<h4>ИНВЕНТАРЬ · ${inv.length}</h4>`+inv.map(it=>{const g=GF[it.k]||{n:'Подарок',i:'🎁',v:0};return `<div class="inv-item"><i>${g.i}</i><div><b>${esc(g.n)}</b><small>⭐ ${fmt(g.v)}</small></div><button type="button" data-gift="${esc(it.id)}">Вывести</button></div>`}).join(''):'';
}
$('#inv').addEventListener('click',e=>{
  const b=e.target.closest('[data-gift]');if(!b)return;
  const go=()=>api('/giftout',{gid:b.dataset.gift}).then(d=>{toast(d&&d.ok?'Заявка на вывод отправлена ✓':(d&&d.error)||'Ошибка сети');if(d&&d.ok)syncPayouts();});
  if(tg&&tg.showConfirm)tg.showConfirm('Отправить заявку на вывод подарка?',ok=>{if(ok)go();});else go();
});
renderInv();renderCase();

render();
